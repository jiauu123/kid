#!/usr/bin/env bash

echo "Running h-run.sh for GPU + CPU mining..."

# Source HiveOS manifest
source "/hive/miners/custom/rqiner-x86-cuda/h-manifest.conf"

# Ensure log directory exists
CUSTOM_LOG_BASEDIR=$(dirname "$CUSTOM_LOG_BASENAME")
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# Check if the configuration files are defined
if [[ -z $CUSTOM_CONFIG_FILENAME ]] || [[ -z $CUSTOM2_CONFIG_FILENAME ]]; then
    echo "The config files are not defined."
    exit 1
fi

# Set the library path
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/hive/lib

# Read configuration files
CUSTOM_USER_CONFIG=$(< $CUSTOM_CONFIG_FILENAME)

# Fetch the base worker name from HiveOS configuration
WORKER_NAME=$(grep -oP 'WORKER_NAME="\K[^"]+' /hive-config/rig.conf)

# Check if the worker name is set
if [[ -z "$WORKER_NAME" ]]; then
    echo "Worker name not found. Please set WORKER_NAME in HiveOS."
    exit 1
fi

# Define unique worker names for CPU and GPU miners
WORKER_NAME_CPU="${WORKER_NAME}_CPU"
WORKER_NAME_GPU="${WORKER_NAME}_GPU"

# Remove any -label, -arch, -t, and -i commands from the user config to avoid duplicates
USER_CONFIG_CLEANED=$(echo "$CUSTOM_USER_CONFIG" | sed 's/-label [^ ]*//g' | sed 's/-arch [^ ]*//g' | sed 's/-t [^ ]*//g' | sed 's/-i [^ ]*//g')

# Extract the architecture argument
ARCH_VALUE=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '(?<=-arch )\S+')

# Validate the extracted architecture
if [[ -z "$ARCH_VALUE" ]]; then
    echo "Missing required argument: -arch for CPU miner."
    exit 1
fi

# Set the path for the CPU miner executable
CPU_MINER_EXECUTABLE="/hive/miners/custom/rqiner-x86-cuda/cpu/rqiner-x86-$ARCH_VALUE"

# Define the log files for the CPU and GPU miners
cpu_log_file="/var/log/miner/custom/custom_cpu.log"
gpu_log_file="/var/log/miner/custom/custom_gpu.log"

# Extract the required arguments from the user config
THREADS=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '(?<=-t )\d+' || echo "")
ID=$(echo "$CUSTOM_USER_CONFIG" | grep -oP '(?<=-i )\S+' || echo "")

# Check for required arguments
if [[ -z "$THREADS" ]]; then
    echo "Missing required argument: -t (threads)."
    exit 1
fi

if [[ -z "$ID" ]]; then
    echo "Missing required argument: -i (ID)."
    exit 1
fi

# Debugging outputs
echo "Cleaned user config: $USER_CONFIG_CLEANED"
echo "ARCH_VALUE=$ARCH_VALUE, THREADS=$THREADS, ID=$ID"

# Construct the command to start the CPU miner
cpu_command="$CPU_MINER_EXECUTABLE -t $THREADS -i $ID -l $WORKER_NAME_CPU $USER_CONFIG_CLEANED"

# Construct the command to start the GPU miner
gpu_command="/hive/miners/custom/rqiner-x86-cuda/gpu/rqiner-x86-cuda --algo qubic --pool qubic1.hk.apool.io:3334 --account CP_tfpgxpp0g8 --cpu-off --worker $WORKER_NAME_GPU $USER_CONFIG_CLEANED"

# Print the final commands for debugging
echo "Executing CPU miner: $cpu_command"
echo "Executing GPU miner: $gpu_command"

# Execute the CPU miner with the constructed command
eval $cpu_command 2>&1 | tee -a "$cpu_log_file" | grep -E "Iterrate:|Successfully submitted share to pool server" >> "$cpu_log_file" &

# Execute the GPU miner with the constructed command
eval $gpu_command 2>&1 | tee -a "$gpu_log_file" | grep -E "Iterrate:|Successfully submitted share to pool server" >> "$gpu_log_file" &

# Wait for all miners to finish
wait

echo "Both CPU and GPU miners have exited."
