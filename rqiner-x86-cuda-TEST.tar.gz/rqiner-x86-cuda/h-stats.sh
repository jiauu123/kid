#!/usr/bin/env bash

# Set log file paths
cpu_log_file="/var/log/miner/custom/custom_cpu.log"
gpu_log_file="/var/log/miner/custom/custom_gpu.log"
output_json="/tmp/hive_miner_stats.json"
debug_log="/var/log/h-stats-debug.log"

# Function to log debugging information
log_debug() {
  echo "$(date '+%Y-%m-%d %H:%M:%S') - $1" >> $debug_log
}

# Function to fetch the miner version from the log
get_miner_version() {
  version=$(grep -m 1 'rqiner v' "$log_file" | awk -F'v' '{print $2}' | awk '{print $1}')
  [[ -z "$version" ]] && version="N/A"
  echo "$version"
}

# Function to fetch the most recent iteration rates for both GPU and CPU miners
get_iterrate() {
  if [[ $(is_idle_state) == "true" ]]; then
    echo "0" # Set to 0 if miners are idle
  else
    cpu_iterrate=$(grep 'rqiner_manager]' "$cpu_log_file" | grep 'Iterrate:' | tail -n 1 | awk -F'Iterrate: ' '{print $2}' | awk '{print $1}')
    gpu_iterrate=$(grep 'qubic_algos::gpu' "$gpu_log_file" | grep 'Iterrate:' | tail -n 1 | awk -F'Iterrate: ' '{print $2}' | awk '{print $1}')

    # Default to 0 if not found
    [[ -z "$cpu_iterrate" ]] && cpu_iterrate="0"
    [[ -z "$gpu_iterrate" ]] && gpu_iterrate="0"

    # Calculate the total iteration rate
    total_iterrate=$(echo "$cpu_iterrate + $gpu_iterrate" | bc)
    echo "$total_iterrate"
  fi
}

# Function to fetch the total number of shares from the logs
get_accepted_shares() {
  shares=$(grep 'Successfully submitted share to pool server' "$cpu_log_file" "$gpu_log_file" | wc -l)
  [[ -z "$shares" ]] && shares="0"
  echo "$shares"
}

# Function to fetch the miner uptime
get_miner_uptime() {
  start_time=$(cat "/tmp/miner_start_time" 2>/dev/null || echo "0")
  current_time=$(date +%s)
  uptime=$((current_time - start_time))
  echo "$uptime"
}

# Check if the log files exist and are not empty
if [[ ! -s "$cpu_log_file" && ! -s "$gpu_log_file" ]]; then
  log_debug "Log files are missing or empty: CPU: $cpu_log_file, GPU: $gpu_log_file"
  exit 1
fi

# Fetch data
uptime=$(get_miner_uptime)
version=$(get_miner_version)
khs=$(get_iterrate)
shares=$(get_accepted_shares)

# Debugging output
log_debug "CPU Log File: $cpu_log_file"
log_debug "GPU Log File: $gpu_log_file"
log_debug "Miner Version: $version"
log_debug "Total Iteration Rate (khs): $khs"
log_debug "Accepted Shares: $shares"
log_debug "Miner Uptime: $uptime"

# Generate JSON output for HiveOS
stats=$(jq -nc \
        --arg total_khs "$khs" \
        --arg hs_units "khs" \
        --arg uptime "$uptime" \
        --arg ver "$version" \
        --arg ac "$shares" \
        --arg algo "qubic" \
        '{$total_khs, $hs_units, $uptime, $ver, "ac":$ac, "algo":$algo}')

# Output JSON to the specified file
echo $stats > $output_json

# Additional debug output to check the JSON content
log_debug "JSON Stats: $stats"
